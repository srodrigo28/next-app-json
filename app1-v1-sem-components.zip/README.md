

npm run api
npm run dev