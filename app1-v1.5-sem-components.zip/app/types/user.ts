export interface User {
    id?: string | number;
    nome: string;
    email: string;
    senha?: string;
}
