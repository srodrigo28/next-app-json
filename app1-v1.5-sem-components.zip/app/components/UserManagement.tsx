'use client';

import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { User } from '../types/user';

// --- SVG Icons ---
const TrashIcon = ({ className = "w-4 h-4" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
    </svg>
);

const EditIcon = ({ className = "w-4 h-4" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10" />
    </svg>
);

const CloseIcon = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
    </svg>
);

const PlusIcon = ({ className = "w-5 h-5" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
    </svg>
);

const RefreshIcon = ({ className = "w-5 h-5" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99" />
    </svg>
);

// --- Schema & Types ---
const userSchema = z.object({
    nome: z.string().min(1, 'O nome é obrigatório'),
    email: z.string().email('Formato de e-mail inválido'),
    senha: z.string().min(3, 'A senha deve ter no mínimo 3 caracteres'),
});

export type UserFormData = z.infer<typeof userSchema>;

// --- Reusable Components ---
interface FormFieldProps {
    label: string;
    type: string;
    placeholder: string;
    error?: string;
    disabled?: boolean;
    autoFocus?: boolean;
    register: any;
}

const FormField = ({ label, type, placeholder, error, disabled, autoFocus, register }: FormFieldProps) => (
    <div className="space-y-2">
        <label className="text-sm text-gray-400 ml-1">{label}</label>
        <input
            type={type}
            {...register}
            className={`w-full bg-black/20 border rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 transition-all ${error ? 'border-red-500 focus:ring-red-500/50' : 'border-white/10 focus:ring-indigo-500/50'
                }`}
            placeholder={placeholder}
            disabled={disabled}
            autoFocus={autoFocus}
        />
        {error && <p className="text-red-400 text-xs ml-1">{error}</p>}
    </div>
);

// --- DeleteUserModal ---
interface DeleteUserModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
    userName?: string;
}

function DeleteUserModal({ isOpen, onClose, onConfirm, userName }: DeleteUserModalProps) {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity">
            <div className="bg-[#111] border border-white/10 rounded-2xl shadow-2xl max-w-md w-full p-6 transform transition-all scale-100 animate-in fade-in zoom-in duration-200">
                <div className="flex flex-col items-center text-center">
                    <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mb-4 border border-red-500/20">
                        <TrashIcon className="w-8 h-8 text-red-500" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">Excluir Usuário?</h3>
                    <p className="text-gray-400 mb-6 py-5">
                        Você está prestes a remover <span className="text-white font-semibold">"{userName}"</span>.
                        <br />Essa ação não pode ser desfeita.
                    </p>
                    <div className="flex gap-3 w-full">
                        <button onClick={onClose} className="flex-1 px-4 py-3 bg-white/5 hover:bg-white/10 text-gray-300 rounded-xl font-medium transition-colors">
                            Cancelar
                        </button>
                        <button onClick={onConfirm} className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-500 text-white rounded-xl font-medium shadow-lg shadow-red-500/20 transition-colors">
                            Sim, Excluir
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

// --- UserFormModal ---
interface UserFormModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSubmit: (data: UserFormData) => Promise<void>;
    initialData?: User | null;
    loading: boolean;
}

function UserFormModal({ isOpen, onClose, onSubmit, initialData, loading }: UserFormModalProps) {
    const { register, handleSubmit, reset, formState: { errors } } = useForm<UserFormData>({
        resolver: zodResolver(userSchema),
        defaultValues: { nome: '', email: '', senha: '' },
    });

    useEffect(() => {
        if (isOpen) {
            reset(initialData ? { nome: initialData.nome, email: initialData.email, senha: initialData.senha || '' } : { nome: '', email: '', senha: '' });
        }
    }, [isOpen, initialData, reset]);

    if (!isOpen) return null;

    const isEditing = !!initialData;
    const btnClass = isEditing
        ? 'bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 shadow-amber-500/20'
        : 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 shadow-indigo-500/20';

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity">
            <div className="bg-[#111] border border-white/10 rounded-2xl shadow-2xl max-w-lg w-full p-8 transform transition-all scale-100 animate-in fade-in zoom-in duration-200 relative">
                <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors">
                    <CloseIcon />
                </button>

                <h2 className="text-2xl font-semibold text-white mb-8 flex items-center gap-3">
                    <span className={`w-2 h-8 rounded-full ${isEditing ? 'bg-amber-500' : 'bg-indigo-500'}`}></span>
                    {isEditing ? 'Editar Usuário' : 'Novo Usuário'}
                </h2>

                <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
                    <FormField label="Nome Completo" type="text" placeholder="Ex: Ana Silva" error={errors.nome?.message} disabled={loading} autoFocus register={register('nome')} />
                    <FormField label="E-mail" type="email" placeholder="Ex: ana@email.com" error={errors.email?.message} disabled={loading} register={register('email')} />
                    <FormField label="Senha" type="password" placeholder="••••••••" error={errors.senha?.message} disabled={loading} register={register('senha')} />

                    <div className="flex gap-3 pt-4">
                        <button type="button" onClick={onClose} className="flex-1 bg-white/5 hover:bg-white/10 text-gray-300 font-bold py-3.5 rounded-xl transition-all">
                            Cancelar
                        </button>
                        <button type="submit" disabled={loading} className={`flex-1 text-white font-bold py-3.5 rounded-xl shadow-lg transition-all transform hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed ${btnClass}`}>
                            {loading ? 'Salvando...' : (isEditing ? 'Salvar Alterações' : 'Criar Usuário')}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}

// --- UserTable ---
interface UserTableProps {
    users: User[];
    onEdit: (user: User) => void;
    onDelete: (user: User) => void;
    editingId?: string | number | null;
}

function UserTable({ users, onEdit, onDelete, editingId }: UserTableProps) {
    return (
        <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
                <thead>
                    <tr className="bg-black/20 text-gray-400 text-xs uppercase tracking-wider">
                        <th className="p-5 font-medium">ID</th>
                        <th className="p-5 font-medium">Usuário</th>
                        <th className="p-5 font-medium">Contato</th>
                        <th className="p-5 font-medium text-right">Ações</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                    {users.map((user) => (
                        <tr key={user.id} className={`group transition-colors ${editingId === user.id ? 'bg-amber-500/5 border-l-2 border-amber-500' : 'hover:bg-white/[0.02]'}`}>
                            <td className="p-5 text-gray-500 font-mono text-sm">#{user.id}</td>
                            <td className="p-5">
                                <div className="flex items-center gap-3">
                                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-700 to-gray-800 flex items-center justify-center text-xs font-bold text-gray-300 border border-white/10">
                                        {user.nome.charAt(0)}
                                    </div>
                                    <span className="text-gray-200 font-medium">{user.nome}</span>
                                </div>
                            </td>
                            <td className="p-5 text-gray-400 text-sm">{user.email}</td>
                            <td className="p-5 text-right">
                                <div className="flex items-center justify-end gap-2">
                                    <button onClick={() => onEdit(user)} className="text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 p-2 rounded-lg transition-colors" title="Editar">
                                        <EditIcon />
                                    </button>
                                    <button onClick={() => onDelete(user)} className="text-red-400 hover:text-red-300 hover:bg-red-500/10 p-2 rounded-lg transition-colors" title="Excluir">
                                        <TrashIcon />
                                    </button>
                                </div>
                            </td>
                        </tr>
                    ))}
                    {users.length === 0 && (
                        <tr>
                            <td colSpan={4} className="p-8 text-center text-gray-500">
                                Nenhum usuário encontrado ou conectando ao servidor...
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
}

// --- UserListHeader ---
interface UserListHeaderProps {
    userCount: number;
    onCreate: () => void;
    onRefresh: () => void;
}

function UserListHeader({ userCount, onCreate, onRefresh }: UserListHeaderProps) {
    return (
        <div className="p-6 border-b border-white/10 flex flex-col sm:flex-row justify-between items-center gap-4">
            <h2 className="text-xl font-semibold text-white">Base de Dados</h2>
            <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
                <button onClick={onCreate} className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg font-medium transition-all shadow-lg shadow-indigo-500/20 hover:scale-105 active:scale-95">
                    <PlusIcon />
                    Novo Usuário
                </button>
                <div className="h-6 w-px bg-white/10 mx-1"></div>
                <button onClick={onRefresh} className="p-2 text-gray-400 hover:text-white transition-colors" title="Atualizar lista">
                    <RefreshIcon />
                </button>
                <span className="bg-indigo-500/20 text-indigo-300 px-3 py-1 rounded-full text-xs font-medium border border-indigo-500/30">
                    {userCount} Registros
                </span>
            </div>
        </div>
    );
}

// --- Main Component ---
export default function UserManagement({ initialUsers }: { initialUsers: User[] }) {
    const [users, setUsers] = useState<User[]>(initialUsers);
    const [loading, setLoading] = useState(false);
    const [editingId, setEditingId] = useState<string | number | null>(null);
    const [userToDelete, setUserToDelete] = useState<User | null>(null);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [isFormModalOpen, setIsFormModalOpen] = useState(false);

    useEffect(() => setUsers(initialUsers), [initialUsers]);

    const fetchUsers = async () => {
        try {
            const res = await fetch('http://localhost:3001/usuarios');
            const data = await res.json();
            setUsers(data);
        } catch (error) {
            console.error("Erro ao buscar usuários:", error);
        }
    };

    const openCreateModal = () => {
        setEditingId(null);
        setIsFormModalOpen(true);
    };

    const openEditModal = (user: User) => {
        setEditingId(user.id || null);
        setIsFormModalOpen(true);
    };

    const closeFormModal = () => {
        setIsFormModalOpen(false);
        setEditingId(null);
    };

    const handleFormSubmit = async (data: UserFormData) => {
        setLoading(true);
        try {
            const url = editingId ? `http://localhost:3001/usuarios/${editingId}` : 'http://localhost:3001/usuarios';
            const method = editingId ? 'PUT' : 'POST';
            const res = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
            });

            if (res.ok) {
                const savedUser = await res.json();
                setUsers(editingId ? users.map(u => u.id === editingId ? savedUser : u) : [...users, savedUser]);
                closeFormModal();
            }
        } catch (error) {
            console.error("Erro ao salvar usuário:", error);
        } finally {
            setLoading(false);
        }
    };

    const requestDelete = (user: User) => {
        setUserToDelete(user);
        setIsDeleteModalOpen(true);
    };

    const confirmDelete = async () => {
        if (!userToDelete?.id) return;

        try {
            await fetch(`http://localhost:3001/usuarios/${userToDelete.id}`, { method: 'DELETE' });
            setUsers(users.filter(user => user.id !== userToDelete.id));
            if (editingId === userToDelete.id) closeFormModal();
            setIsDeleteModalOpen(false);
            setUserToDelete(null);
        } catch (error) {
            console.error("Erro ao deletar usuário:", error);
        }
    };

    const editingUser = users.find(u => u.id === editingId) || null;

    return (
        <div className="w-full max-w-6xl mx-auto p-6 relative">
            <DeleteUserModal isOpen={isDeleteModalOpen} onClose={() => setIsDeleteModalOpen(false)} onConfirm={confirmDelete} userName={userToDelete?.nome} />
            <UserFormModal isOpen={isFormModalOpen} onClose={closeFormModal} onSubmit={handleFormSubmit} initialData={editingUser} loading={loading} />

            <div className="mb-12 text-center space-y-4">
                <h1 className="text-5xl font-extrabold bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent drop-shadow-sm">
                    Painel de Usuários
                </h1>
                <p className="text-gray-400 text-lg">Gerenciado via JSON Server</p>
            </div>

            <div className="w-full">
                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
                    <UserListHeader userCount={users.length} onCreate={openCreateModal} onRefresh={fetchUsers} />
                    <UserTable users={users} onEdit={openEditModal} onDelete={requestDelete} editingId={editingId} />
                </div>
            </div>
        </div>
    );
}
